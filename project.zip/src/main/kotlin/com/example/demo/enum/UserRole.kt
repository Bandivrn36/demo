package com.example.demo.enum

enum class UserRole {
    USER,
    ADMIN
}